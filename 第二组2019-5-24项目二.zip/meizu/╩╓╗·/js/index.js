$(function () {
    var li = $('.nav_left>li');
    var box = $('.sub_nav');
    $.each(li, function (index, value) {
        $(this).hover(function () {
            box.eq(index).slideDown(500)
        }, function () { box.eq(index).css('display', 'none') })
    })

    var li2 = $('.header>.nav>.nav_right>li')
    var box2 = $('.header>.nav>.nav_right>li>.sub_nav2')
    $.each(li2, function (index, value) {
        $(this).hover(function () {
            box2.eq(index).css('display', 'block')
        }, function () { box2.eq(index).css('display', 'none') })
    })

    //底部轮播

    var btn = $('.btn_list>button');
    var img10 = $('.img_list');
    var img10_index = 0;
    var img10_index_next = 1;
    var img10_width = $('.img_list').width();

    var time;

    img10.eq(0).css('zIndex', 2).css('left', '0px');
    img10.eq(1).css('zIndex', 2).css('left', img10_width + 'px');
    $.each(btn, function (index, value) {
        $(this).click(function () {
            if (!!time) {
                clearInterval(time)
            }
            img10_index = index;
            if (img10_index == img10.length - 1) {
                img10_index_next = 0
            } else if (img10_index > img10.length - 1) {
                img10_index = 0;
                img10_index_next = 1;
            } else (img10_index_next = img10_index + 1)
            img10.eq(img10_index).css('zIndex', 3).css('left', '0px').siblings().css('zIndex', 1);
            img10.eq(img10_index_next).css('left', img10_width + 'px')
            btn.eq(index).addClass('active').siblings().removeClass('active');
            imgAnimate();
        })
    })
    function imgAnimate() {
        time = setInterval(function () {
            if (img10_index == img10.length - 1) {
                img10_index_next = 0
            } else if (img10_index > img10.length - 1) {
                img10_index = 0;
                img10_index_next = 1;
            } else (img10_index_next = img10_index + 1)
            img10.eq(img10_index).css('zIndex', 1).css('left', '0px').animate({ left: -img10_width + 'px' }, 2000);
            img10.eq(img10_index_next).css('zIndex',1).css('left', img10_width + 'px').animate({ left: '0px' }, 2000)
            btn.eq(img10_index_next).addClass('active').siblings().removeClass('active');
            img10_index++;
        },5000)
    }
    imgAnimate();


    //图片大小变化
    //content下
    var img_list_img = $('.img_list img');
    var img_1 = $('.img_1')
    $.each(img_list_img, function (index, value) {
        $(this).hover(function () {
            img_list_img.eq(index).css('width', '320px').css('height', '320px')
        }, function () {
            img_list_img.eq(index).css('width', '300px').css('height', '300px')
        })
    })
    //content中
    var img = $('.sub_shouji img');
    var img_parent = $('.sub_shouji>.img')
    $.each(img, function (index, value) {
        $(this).hover(function () {
            img.eq(index).css('width', '350px').css('height', '350px')
        }, function () {
            img.eq(index).css('width', '330px').css('height', '330px')
        })
    })
    //header

    var img2 = $('header .sub_nav>.wrap>ul>li>dl>dt img')
    var img2_parent = $(' header .sub_nav>.wrap>ul>li>dl>dt')
    $.each(img2, function (index, value) {
        $(this).hover(function () {
            img2.eq(index).css('width', '110px').css('height', '110px')
        }, function () {
            img2.eq(index).css('width', '100px').css('height', '100px')
        })
    })

    var a = $('footer>article>.foot>ul>.language>.lan_box');
    var b = $('footer>article>.foot>ul>.language')
    $.each(b, function () {
        $(this).hover(function () {
            a.css('display', 'block')
        }, function () {
            a.css('display', 'none')
        })
    })

//底部
    var first = $('footer>article>.foot>.end>ul>li .first')
    var second = $('footer>article>.foot>.end>ul>li .second')
    var four = $('footer>article>.foot>.end>ul>li')
    var three = $('footer>article>.foot>.end>ul>.three')

    $.each(four, function (index, value) {
        $(this).hover(function () {
            first.eq(index).css('zIndex', '1')
            second.eq(index).css('zIndex', '3')
            three.eq(index).css('display', 'block')
        }, function () {
            first.eq(index).css('zIndex', '3')
            second.eq(index).css('zIndex', '1')
            three.eq(index).css('display', 'none')
        })
    })
var img_9=$('.img_9');
img_9.css('display','block')


    var imgp=$('.content_2>.shouji .sub_shouji>.img>img');
    var btnp=$('.content_2>.shouji .sub_shouji>.yanse>button');
    $.each(btnp,function(index,value){
        $(this).click(function(){
            imgp.eq(index).css('display','block').siblings().css('display','none')
            btnp.eq(index).addClass('btn1').siblings().removeClass('btn1')
        })
    })
    
})