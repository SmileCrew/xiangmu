// ----------------------Top rptation chart----------------------
$(function(){
    var btn = $('.list_btn>span');
    var img = $('.img_list>img');
    var img_width = $('.img_list').width();
    var time;
    var img_index=0;
    var img_next_index=img_index+1;

    img.eq(0).css('zIndex',2).css('left','0px');
    img.eq(1).css('zIndex',2).css('left',img_width+'px');

    $.each(btn,function(index,value){
        $(this).click(function(){
            if(!!time){
                clearInterval(time);
            }
            // time=setInterval(function(){
            //     clearInterval(time);
            // });
            // function imgAnimate(){
            //     clearInterval(time);
            // }
            img_index=index;
            if(img_index==img.length-1){
                img_next_index=0;
            }else if(img_index>img.length-1){
                img_index=0;
                img_next_index=1;
            }else{img_next_index=img_index+1;}
            img.eq(img_index).css('zIndex',3).css('left','0px').siblings().css('zIndex',1);
            img.eq(img_next_index).css('left',img_width+'px');
            btn.eq(img_index).addClass('active').siblings().removeClass('active');
            
    imgAnimate();
    
        });

    });
    imgAnimate();
    function imgAnimate(){
        time=setInterval(function(){
            if(img_index==img.length-1){
                img_next_index=0;
            }else if(img_index>img.length-1){
                img_index=0;
                img_next_index=1;
            }else{img_next_index=img_index+1;}
            img.eq(img_index).css('zIndex',1).css('left','0px').animate({left:-img_width+'px'},2000);
            img.eq(img_next_index).css('zIndex',1).css('left',img_width+'px').animate({left:'0px'},2000);
            btn.eq(img_next_index).addClass('active').siblings().removeClass('active');
            img_index++;
        },3000);
    }
})
/* -------------------The top menu bar is displayed and hidden------------------ */
$(function(){
    var li = $('.msg');
    var div = $('.submenu');
    li.hover(function(){
        div.slideToggle(500).css('display','block');
    },function(){
        div.css('display','none');
    },function(){
        div.css('zIndex',-2)
    })
});
$(function(){
    var li1 = $('.msg1');
    var div = $('.submenu1');
    li1.hover(function(){
        div.css('display','block');
    },function(){
        div.css('display','none');
    },function(){
        div.css('zIndex',-2)
    })
});
$(function(){
    var li2 = $('.msg2');
    var div = $('.submenu2');
    li2.hover(function(){
        div.css('display','block');
    },function(){
        div.css('display','none');
    },function(){
        div.css('zIndex',-2)
    })
});
$(function(){
    var li3 = $('.msg3');
    var div = $('.submenu3');
    li3.hover(function(){
        div.css('display','block');
    },function(){
        div.css('display','none');
    },function(){
        div.css('zIndex',-2)
    })
});
$(function(){
    var li4 = $('.last');
    var div = $('.submenu4');
    li4.hover(function(){
        div.css('display','block');
    },function(){
        div.css('display','none');
    },function(){
        div.css('zIndex',-2)
    })
});
// $(function(){
//     var li = $('.msg');
//     var div = $('.submenu');
//     li.hover(function(){
//         div.slideUp(1000,function(){
//             div.css('display','block');
//         },function(){
//             div.css('display','none');
//         })
//     })
// })
/* -----------------------Bottom right corner picture--------------------------- */
$(function(){

    var img1 = $('.footer_con>li>a>.img_show');
    var li1 = $('.footer_con>.img_over');
    var img2 = $('.footer_con>li>a>.img_mouse');
    // alert(li1.length)
    li1.hover(function(){
        img1.css('display','block');
    },function(){
        img1.css('display','none');
    });
    li1.hover(function(){
        img2.css('display','block');
    },function(){
        img2.css('display','none');
    })
});
$(function(){
    var li = $('.footer_con>.img_over1');
    var img=$('.img_over1>a>.img_show1');
    var img1=$('.img_over1>a>.img_mouse1');

    li.hover(function(){
        img.css('display','block');
    },function(){
        img.css('display','none');
    });
    li.hover(function(){
        img1.css('display','block');
    },function(){
        img1.css('display','none');
    })
});
$(function(){
    var li = $('.footer_con>.img_over2');
 
    var img=$('.img_over2>a>.img_mouse2');

    li.hover(function(){
        img.css('display','block');
    },function(){
        img.css('display','none');
    });
});
$(function(){
    var li = $('.footer_con>.img_over3');
 
    var img=$('.img_over3>a>.img_mouse3');

    li.hover(function(){
        img.css('display','block');
    },function(){
        img.css('display','none');
    });
});