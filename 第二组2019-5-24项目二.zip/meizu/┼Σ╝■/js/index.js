$(function(){
    var li1=$('.content_nav li');
    var div=$('.bottom_nav');
    var li2=$('#luobo_bottom li');
    var img=$('#show_main img');
    var span=$('span');
    var img1=$('.tab_bottom img');
    $.each(li1,function(index){
        $(this).hover(function(){
                div.eq(index).css('display','block');
        },function(){
                div.eq(index).css('display','none');
        })
    })
    $.each(li2,function(index){
        $(this).click(function(){
            img.attr("src","images/big" + (index+1) + ".jpg");

        })
    })
    $.each(span,function(index){
        $(this).click(function(){
            img1.eq(index).css('display','block').siblings().css('display','none');
            
            $(this).attr('class','br').siblings().removeAttr('class','br');
        })
    })
})