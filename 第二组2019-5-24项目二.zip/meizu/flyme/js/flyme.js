$(function () {
      var btn = $('.list_btn button');
      var img = $('.banner img');


      var img_width = $('.banner').width();



      //设定定时器变量
      var time;
      //设定【当前轮播图片】索引值记数

      var img_index = 0;
      //设定【下一张轮播图片】索引值记数
      var img_next_index;

      //初始化轮播图片初始位置
      img.eq(0).css('zIndex', 2).css('left', '0px');
      img.eq(1).css('zIndex', 2).css('left', img_width + 'px');


      var index_array = [];

      //手动轮播

      $.each(btn, function (index, value) {

            $(this).click(function () {

                  if (!!time) {
                        clearInterval(time);
                  }



                  img_index = index;

                  if (img_index == img.length - 1) {

                        img_next_index = 0;

                  } else if (img_index > img.length - 1) {

                        img_index = 0;
                        img_next_index = 1;

                  } else {

                        img_next_index = img_index + 1;
                  }



                  img.eq(img_index).css('zIndex', 3).css('left', '0px').siblings().css('zIndex', 1);
                  // img.eq(img_next_index).css('left',img_width+'px'); 

                  btn.eq(img_index).addClass('active').siblings().removeClass('active');

                  imgAniamte();

            });


      });

      //     自动轮播


      imgAniamte();


      function imgAniamte() {

            time = setInterval(function () {


                  if (img_index<img.length - 1) {

                        img_next_index = 0;

                  } else if (img_index > img.length - 1) {

                        img_index = 0;
                        img_next_index = 1;

                  } else {

                        img_next_index = img_index + 1;
                  }


                  /*水平动画轮播*/
                  img.eq(img_index).css('zIndex', 1).css('left', '0px').animate({ left: -img_width + 'px' }, 1000);
                  img.eq(img_next_index).css('zIndex', 1).css('left', img_width + 'px').animate({ left: '0px' }, 1000);



                  /*文字信息、按钮切换*/
                  btn.eq(img_next_index).addClass('active').siblings().removeClass('active');


                  img_index++;




            }, 2000);

      }




      var threeimg = $('section .centent_three .three_box .three_smallbox')
      var erweima = $('.erweima')

      $.each(threeimg, function (index, value) {
            $(this).hover(function () {
                  erweima.eq(index).animate({ opacity: 1 }, 1000).show()
            }, function () {
                  erweima.eq(index).animate({ opacity: 0 }, 1000).hide()
            })
      })

      var nav = $('header .nav');
      var bigimg=$('.banner')
      var navTop=nav.height();
      $(document).scroll(function(){
            //多张图片加载用EACH   针对IMG触发条件
            $.each(nav,function(index,value){
                //当 当前图片距离页面顶部的距离  -    滚动条的距离  <  可视区的距离  
                if(bigimg.height()/2   < $(document).scrollTop()) {
                    // 执行 当前图片 加载 属性  引入图片地址的索引值 +动画效果透明度为1 延迟2秒显示
                    $(this).css('background','#fff')
                }else{  $(this).css('background','none')}
            })
        })


var lunbo =$('.lunbo');
var luhnbo_width = $('.lunbo').height();


      



setInterval(function () {
      lunbo.slideToggle(1000);
  },3000);









      var shadow =$('section .centent_two span')
        $.each(shadow,function(index,value){
              $(this).hover(function(){
                  $(this).addClass('mz-yy')
              },function(){
                  $(this).removeClass('mz-yy')
              })
        })


})