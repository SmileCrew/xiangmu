$(function () {
    var li = $('ul>li');
    var div =$('.nav_2')
    // var list =$('.list');
    console.log(li.length)
    // console.log(list.length)
    console.log(div.length)
  
    $.each(li,function(index,value) {

        $(this).hover(function () {

            div.eq(index).css('display', 'block')
        }, function(){

            div.eq(index).css('display', 'none')

        });

    });

});