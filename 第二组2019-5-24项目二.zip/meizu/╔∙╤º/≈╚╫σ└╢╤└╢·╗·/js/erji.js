$(function () {
    var li = $('ul>li');
    var div =$('.nav_2')


    $.each(li,function(index,value) {

        $(this).hover(function () {

            div.eq(index).css('display', 'block')
        }, function(){

            div.eq(index).css('display', 'none')

        });

    });











    
   var liimg=$('.dianji3 img')
   var imgli=$('.img_list li')
       // var list =$('.list');
       console.log(liimg.length)
       // console.log(list.length)
       imgli[0].style.border = "2px solid red";
    //    $.each(imgli,function(index,value){
    //        $(this).click(function(){
    //         $(this).eq(index).style.border = "none";
    //        },function(){
     
    //         $(this).eq(index).style.border = "2px solid red";
    //        })
    //    })
       $.each(imgli,function(index,value){
        //li的点击事件执行程序
       $(this).click(function(){
           //点击当前li之后CSS的样式发生改变  除当前点击LI之外其他兄弟元素CSS样式也发生变化
        $(this).css('border', "2px solid red").siblings().css('border', "none")
            //点击当前li之后CSS的样式发生改变  除当前点击LI之外其他兄弟元素CSS样式也发生变化
        // $(this).css('color','#333').siblings().css('color','#fff');
        //盒子精准到（索引值的CSS样式发生改变 除当前盒子之外其他盒子CSS样式也发生改变
        liimg.eq(index).css('display','block').siblings().css('display','none');
      
    })
    })
})