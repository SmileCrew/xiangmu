$(function(){
    var li = $('.header ul.header_left li');
    var div =$('.header ul.header_left li .main');
    var list =$('.to_art .list_btn button');
    var img_list=$('.to_art .to_all .to_main');
    var reg_img =$('.header ul.header_right li.reg img');
    var top_id =$('.header ul.header_right>li.reg>ul.top_id');
    var top_id_li =$('.header ul.header_right>li.reg>ul.top_id>li'); 
    $.each(li,function(index,value){
        $(this).hover(function(){
            div.eq(index).css('display','block');
        } ,function(){
            div.eq(index).css('display','none');
        });
    });
    $.each(list,function(index,value){
       $(this).click(function(){
           img_list.eq(index).css('display','block').siblings().css('display','none');
           $(this).css('background','grey').siblings().css('background','#fff');
       });   
    });
    $.each(reg_img,function(index,value){
        $(this).hover(function(){
            top_id.eq(index).css('display','block');
        },function(){
            top_id.eq(index).css('display','none');
        });
    });
    $.each(top_id_li,function(){
       $(this).mouseover(function(){
           $(this).css('background','grey').siblings().css('background','#fff');
       }); 
    }); 
});