$(function () {
    var li = $('header .head-container .nav .listone li')
    var list1 = $('header .head-container .nav .listone li .listtwo')
    var box = $('header .head-container .nav .listone li')

    var btn = $('#list_btn span');
    var img = $('#img_main img');
    var img_width = $('#img_main').width();
    //设定定时器变量
    var time;
    //设定【当前轮播图片】索引值记数

    var img_index = 0;
    //设定【下一张轮播图片】索引值记数
    var img_next_index;

    //初始化轮播图片初始位置
    img.eq(0).css('zIndex', 2).css('left', '0px');
    img.eq(1).css('zIndex', 2).css('left', img_width + 'px');
    //console.log(li.length)
    $.each(li, function (index, value) {
        $(this).hover(function () {
            list1.eq(index).css('display', 'block');
        }, function () {
            list1.eq(index).css('display', 'none');
        });
    });
    // box.mouseover(function () {

    //     $(this).css('background', '#fff').siblings().css('background', '#010121');

    // });
    //手动轮播

    $.each(btn, function (index, value) {

        $(this).click(function () {

            if (!!time) {
                clearInterval(time);
            }



            img_index = index;

            if (img_index == img.length - 1) {

                img_next_index = 0;

            } else if (img_index > img.length - 1) {

                img_index = 0;
                img_next_index = 1;

            } else {

                img_next_index = img_index + 1;
            }


            /*点击切换到当前图片*/

            img.eq(img_index).css('zIndex', 3).css('left', '0px').siblings().css('zIndex', 1);
            img.eq(img_next_index).css('left', img_width + 'px');



            /*文字信息、按钮切换*/
            btn.eq(img_index).addClass('active').siblings().removeClass('active');


            imgAniamte();

        });


    });

    imgAniamte();
    function imgAniamte() {

        time = setInterval(function () {


            if (img_index == img.length - 1) {

                img_next_index = 0;

            } else if (img_index > img.length - 1) {

                img_index = 0;
                img_next_index = 1;

            } else {

                img_next_index = img_index + 1;
            }


            /*水平动画轮播*/
            img.eq(img_index).css('zIndex', 1).css('left', '0px').animate({ left: -img_width + 'px' }, 1000);
            img.eq(img_next_index).css('zIndex', 1).css('left', img_width + 'px').animate({ left: '0px' }, 1000);

            btn.eq(img_next_index).addClass('active').siblings().removeClass('active');

            img_index++;
        }, 2000);

    }

    var QR = $('section .contect .way .QR img')
    var QR1 = $('section .contect .way .QR')

    QR.mouseout(function () {
        $(this).css('display', 'none');
    });

    $.each(QR1, function (index, value) {
        $(this).mouseover(function () {
            QR.css('display', 'block');
        // }, function () {
        //     li3.css('zIndex', '0');
         });
    });
    
    
    var pox = $('section .center-nav .product ul li a img')
    var width =  pox.position().top
    var height = pox.position().left
     console.log(pox.position().top)
     console.log(height)
    // setInterval(function(){
    //     width++;
    //     pox.css('width',width + 'px')
    // },1000)

});