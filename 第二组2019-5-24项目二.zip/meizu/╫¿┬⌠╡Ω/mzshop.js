$(function(){
    var li=$('ul#nav_down>li')
    var nav_down_0=$('ul>li>ul.nav_down_0')
    console.log(li.length)
    $.each(li,function(index,value){
          $(this).hover(function(){
            nav_down_0.eq(index).css('display','block');

          },function(){
            nav_down_0.eq(index).css('display','none');
          })
    })
})
/*tab切换栏*/
$(function(){

  var fm = $('.index-content>.tab>.qh>.fm');
  var div =$('.tab-1>div');
  var b=$('.index-content>.tab>.qh>.fm>b')
// console.log(fm.length)
// console.log(div.length)
console.log(b.length)
  $.each(fm,function(index,value){
     $(this).click(function(){

         $(this).css('color','#00c3f5').siblings().css('color','#000');
         div.eq(index).css('display','block').siblings().css('display','none');

     });
  });

});
/*地图*/
$(function () {
  ShowMap('113.551247,22.36274', '珠海香洲唐家湾高新区认证店', '珠海市唐家湾高新区留诗路2号厂房1楼魅力科技有限公司前台', '0756-61205269/0756-61204236', '021-888888888', '20');
})
function getInfo(id) {
  $.ajax({
      type: "POST",
      url: "WebUserControl/Contact/GetInfo.ashx",
      cache: false,
      async: false,
      data: { ID: id },
      success: function (data) {
          data = eval(data);
          var length = data.length;
          if (length > 0) {
              ShowMap(data[0]["Image"], data[0]["NewsTitle"], data[0]["Address"], data[0]["Phone"], data[0]["NewsTags"], data[0]["NewsNum"]);
          }
      }
  });
}
function ShowMap(zuobiao, name, addrsee, phone, chuanzhen, zoom) {
  var arrzuobiao = zuobiao.split(',');
  var map = new BMap.Map("allmap");
  map.centerAndZoom(new BMap.Point(arrzuobiao[0], arrzuobiao[1]), zoom);
  map.addControl(new BMap.NavigationControl());
  var marker = new BMap.Marker(new BMap.Point(arrzuobiao[0], arrzuobiao[1]));
  map.addOverlay(marker);
  var infoWindow = new BMap.InfoWindow('<p style="color: #bf0008;font-size:14px;">' + name + '</p><p>地址：' + addrsee + '</p><p>电话：' + phone + '</p><p>传真：' + chuanzhen + '</p>');
  marker.addEventListener("click", function () {
      this.openInfoWindow(infoWindow);
  });
  marker.openInfoWindow(infoWindow);
}
/*000*/
$(function(){

  var img1 = $('.footer_con>li>a>.img_show');
  var li1 = $('.footer_con>.img_over');
  var img2 = $('.footer_con>li>a>.img_mouse');
  // alert(li1.length)
  li1.hover(function(){
      img1.css('display','block');
  },function(){
      img1.css('display','none');
  });
  li1.hover(function(){
      img2.css('display','block');
  },function(){
      img2.css('display','none');
  })
});
$(function(){
  var li = $('.footer_con>.img_over1');
  var img=$('.img_over1>a>.img_show1');
  var img1=$('.img_over1>a>.img_mouse1');

  li.hover(function(){
      img.css('display','block');
  },function(){
      img.css('display','none');
  });
  li.hover(function(){
      img1.css('display','block');
  },function(){
      img1.css('display','none');
  })
});
$(function(){
  var li = $('.footer_con>.img_over2');

  var img=$('.img_over2>a>.img_mouse2');

  li.hover(function(){
      img.css('display','block');
  },function(){
      img.css('display','none');
  });
});
$(function(){
  var li = $('.footer_con>.img_over3');

  var img=$('.img_over3>a>.img_mouse3');

  li.hover(function(){
      img.css('display','block');
  },function(){
      img.css('display','none');
  });
});